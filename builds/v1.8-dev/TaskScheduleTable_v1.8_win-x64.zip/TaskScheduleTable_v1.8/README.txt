TaskScheduleTable v1.8 開発版

タスク_予定表.exe を起動してください。

Voiceフォルダー:
対応するWAVを入れると音声通知を使用できます。

データ保存先:
%LOCALAPPDATA%\TaskScheduleTable\Data
